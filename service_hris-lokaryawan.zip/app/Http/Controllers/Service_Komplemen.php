<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;

class Service_Komplemen extends Controller
{
     // Get List Cuti Karyawan
     public function getListMasterKomplemen(Request $request)
     {
        $tahun = $request->tahun;
        $idKaryawan = $request->id_karyawan;

         try
         {
             $data_ = DB::table('komplement_mst')
             ->select(
             'users.departemen',
             'users.sub_departemen',
             'users.grade',
             'users.name',
             'komplement_mst.id_karyawan','komplement_mst.tahun',
             DB::raw("(select tipe_komplement from komplement_mst where id_karyawan = komplement_mst.id_karyawan and id_komplement='KM001' limit 1) as tipe_komplement_gratis"),
             DB::raw("(select sisa_komplement from komplement_mst where id_karyawan = komplement_mst.id_karyawan and id_komplement='KM001' limit 1) as sisa_komplement_gratis"),
             DB::raw("(select date_start from komplement_mst where id_karyawan = komplement_mst.id_karyawan and id_komplement='KM001' limit 1) as date_start_gratis"),
             DB::raw("(select date_end from komplement_mst where id_karyawan = komplement_mst.id_karyawan and id_komplement='KM001' limit 1) as date_expied_gratis"),

             DB::raw("(select tipe_komplement from komplement_mst where id_karyawan = komplement_mst.id_karyawan and id_komplement='KM002' limit 1) as tipe_komplement_bayar"),
             DB::raw("(select sisa_komplement from komplement_mst where id_karyawan = komplement_mst.id_karyawan and id_komplement='KM002' limit 1) as sisa_komplement_bayar"),
             DB::raw("(select date_start from komplement_mst where id_karyawan = komplement_mst.id_karyawan and id_komplement='KM002' limit 1) as date_start_bayar"),
             DB::raw("(select date_end from komplement_mst where id_karyawan = komplement_mst.id_karyawan and id_komplement='KM002' limit 1) as date_expied_bayar")
                         
             )
             ->join('users','users.id_karyawan','komplement_mst.id_karyawan')
             ->where('komplement_mst.is_dell','1');
             if($data_->exists())
             {       
                if($idKaryawan !='')
                {
                    $data_->where('komplement_mst.id_karyawan',$idKaryawan);
                }
                    $data_->where('komplement_mst.tahun',$tahun);
                    $data_->distinct('komplement_mst.id_karyawan');
                    $data_->orderBy('users.nik','asc');
                    $data = $data_->get();
                    $result=response()->json([
                        'status' => 'success',
                        'message' => 'Get Data Master Cuti Successfuly',
                        'data' => $data
                    ]);
             }
             else
             {
                 $result=response()->json([
                     'status' => 'failed',
                     'message' => 'Get Data Master Cuti Not Successfuly',
                 ]);
             }
 
             return $result;
         } catch (\Exception $ex) {
             return $ex;
         }
     }
}

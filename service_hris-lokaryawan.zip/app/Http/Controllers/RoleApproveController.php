<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\RoleApprove;

class RoleApproveController extends Controller
{
    // menambahkan data Role Approve ke table master
    public function insertRole($idDepartemen_,$departemen_, $idSubDepartemen_,$subDepartemen_, $grade_, $name_, $idKaryawan_, $nik_, $password_, $isDell_)
    {
        // declare variable
        $idDepartemen = $idDepartemen_;
        $departemen = $departemen_;
        $idSubDepartemen = $idSubDepartemen_;
        $subDepartemen = $subDepartemen_;
        $grade = $grade_;
        $name = $name_;
        $idKaryawan = $idKaryawan_;
        $nik = $nik_;
        $password = $password_;
        $isDell = $isDell_;

        try {
            // cek data
            $dt = DB::table('users')
            ->select('id')
            ->where('id_karyawan',$idKaryawan);
            if($dt->exists())
            {
                // data sudah ada
                // data enable (update) 1
                // data disable (delete) 2
                if($isDell=='1')
                {
                    $req = $this->update($idDepartemen,$departemen, $idSubDepartemen,$subDepartemen, $grade, $name, $idKaryawan, $nik, $password);
                }
                else
                {
                    $req = $this->delete();
                }
            }
            else
            {
                // data belum ada
                // insert
                $req = $this->insert($idDepartemen,$departemen, $idSubDepartemen,$subDepartemen, $grade, $name, $idKaryawan, $nik, $password);
            }

            return 'data berhasil ditambahkan';
        } catch (\Exception $ex) {
            return $ex;
        }
    }
}
